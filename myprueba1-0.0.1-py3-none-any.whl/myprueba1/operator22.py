class Operador:
    def __init__(self, num1:int, num2:int) -> None:
        self.num1=num1
        self.num2=num2
        pass

    def add(self):
        return self.num1+self.num2
    
    def sub(self,inverse:bool=False):
        if inverse:
            return self.num2-self.num1
        return self.num1-self.num2
    
    def mul(self):
        return self.num1*self.num2
    
    def div(self):
        return self.num1/self.num2
            
    
